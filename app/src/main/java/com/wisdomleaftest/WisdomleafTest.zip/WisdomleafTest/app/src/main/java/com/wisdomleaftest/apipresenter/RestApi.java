package com.wisdomleaftest.apipresenter;

import com.wisdomleaftest.screens.main.model.Model;

import retrofit.Call;
import retrofit.http.GET;
import retrofit.http.Headers;
import retrofit.http.Query;

public interface RestApi {


    @Headers("Content-Type: application/json")
    @GET(ApiConstants.List)
    Call<Model> list(@Query("page") String pageNo, @Query("limit") String limit);

   }
