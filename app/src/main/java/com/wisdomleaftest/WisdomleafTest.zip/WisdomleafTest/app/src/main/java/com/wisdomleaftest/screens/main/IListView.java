package com.wisdomleaftest.screens.main;

import com.wisdomleaftest.screens.main.model.Model;

public interface IListView {

    void setList(Model model);

}
