
package com.wisdomleaftest.screens.main.model;


import java.util.List;

public class Model {

    private List<Datum> list;

    public List<Datum> getList() {
        return list;
    }

    public void setList(List<Datum> list) {
        this.list = list;
    }
}
