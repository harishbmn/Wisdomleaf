package com.wisdomleaftest.screens.main;

import android.content.Context;
import android.widget.Toast;

import com.wisdomleaftest.apipresenter.APIResponsePresenter;
import com.wisdomleaftest.apipresenter.ApiReqType;
import com.wisdomleaftest.interfaces.IRequestInterface;
import com.wisdomleaftest.interfaces.IResponseInterface;
import com.wisdomleaftest.screens.main.model.Model;
import com.wisdomleaftest.singelton.AppController;

import retrofit.Response;

public class ListPresenter implements IListPresenter, IResponseInterface {
    private final IRequestInterface iRequestInterface;
    private IListView iListView;
    Context context;

    public ListPresenter(IListView iListView) {
        this.iRequestInterface = new APIResponsePresenter(this);
        this.iListView = iListView;
    }

    @Override
    public void onResponseSuccess(Response response, String reqType) {

        if (response != null) {
            if (reqType.equalsIgnoreCase(ApiReqType.List)) {
                Model model = (Model) response.body();
                iListView.setList(model);
            }
        }
    }

    @Override
    public void onResponseFailure(String responseError) {
        Toast.makeText(context, "Response failed"+responseError, Toast.LENGTH_SHORT).show();

    }

    @Override
    public void getList(String pageNo, String limit) {
        iRequestInterface.CallApi(AppController.getInstance().service.list(pageNo, limit), ApiReqType.List);

    }
}
