package com.wisdomleaftest.screens.main;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.wisdomleaftest.R;
import com.wisdomleaftest.screens.main.adapter.ListAdapter;
import com.wisdomleaftest.screens.main.model.Model;

public class ListActivity extends AppCompatActivity implements IListView {
    RecyclerView recyclerView;
    private ListAdapter listAdapter;
    private IListPresenter iListPresenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        recyclerView = findViewById(R.id.recyclerviewId);
        iListPresenter = new ListPresenter(this);
        initRecycler();
    }

    private void initRecycler() {
        final LinearLayoutManager mLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        listAdapter = new ListAdapter(iListPresenter, this);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(listAdapter);

        iListPresenter.getList("1","20");

    }

    @Override
    public void setList(Model model) {
        if (model !=null){
            listAdapter.setData(model);
        }
    }
}