package com.wisdomleaftest.apipresenter;

public class ApiReqType {

    public static final String List = "List";

}


