package com.wisdomleaftest.apipresenter;

public class ApiConstants {


//    https://picsum.photos/v2/list?page=2&limit=20
    public static final String BASE_URL = " https://picsum.photos/v2/";


    public static final String List = BASE_URL + "list";
   }
