package com.wisdomleaftest.screens.main;

public interface IListPresenter {

    void getList(String pageNo, String limit);

}
