package com.wisdomleaftest.interfaces;


import retrofit.Call;

public interface IRequestInterface {

    void CallApi(Call call, String reqType);

}
